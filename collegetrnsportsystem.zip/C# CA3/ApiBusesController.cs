using Microsoft.AspNetCore.Mvc;
using CollegeTransportSystem.Services;

namespace CollegeTransportSystem.Controllers
{
    [ApiController]
    [Route("api/buses")]
    public class ApiBusesController : ControllerBase
    {
        private readonly ITransportService _service;

        public ApiBusesController(ITransportService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetBuses()
        {
            var buses = _service.GetApiBuses();
            return Ok(buses);
        }
    }
}