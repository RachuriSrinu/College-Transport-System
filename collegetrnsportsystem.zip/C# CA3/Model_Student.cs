namespace CollegeTransportSystem.Models
{
    public class Student
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string RegistrationNumber { get; set; } = string.Empty;
        public string Department { get; set; } = string.Empty;
        public int Year { get; set; }
        public string Address { get; set; } = string.Empty;

        public User User { get; set; } = null!;
    }
}