using Microsoft.AspNetCore.Mvc;
using CollegeTransportSystem.Services;

namespace CollegeTransportSystem.Controllers
{
    [ApiController]
    [Route("api/students")]
    public class ApiStudentsController : ControllerBase
    {
        private readonly ITransportService _service;

        public ApiStudentsController(ITransportService service)
        {
            _service = service;
        }

        [HttpGet("{id}/passes")]
        public IActionResult GetPasses(int id)
        {
            var passes = _service.GetApiStudentPasses(id);
            return Ok(passes);
        }
    }
}