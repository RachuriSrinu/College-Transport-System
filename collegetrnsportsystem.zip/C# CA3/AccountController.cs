using Microsoft.AspNetCore.Mvc;
using CollegeTransportSystem.Models;
using CollegeTransportSystem.Services;
using CollegeTransportSystem.ViewModels;

namespace CollegeTransportSystem
{
    public class AccountController : Controller
    {
        private readonly ITransportService _service;

        public AccountController(ITransportService service)
        {
            _service = service;
        }

        public IActionResult Login()
        {
            if (HttpContext.Session.GetInt32("UserId") != null)
            {
                var role = HttpContext.Session.GetString("UserRole");
                return role switch
                {
                    "Admin" => RedirectToAction("Dashboard", "Admin"),
                    "Student" => RedirectToAction("Dashboard", "Student"),
                    "Driver" => RedirectToAction("Dashboard", "Driver"),
                    _ => RedirectToAction("Login")
                };
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var user = _service.GetUserByEmail(model.Email);
            if (user != null && _service.ValidateUser(model.Email, model.Password))
            {
                HttpContext.Session.SetInt32("UserId", user.Id);
                HttpContext.Session.SetString("UserRole", user.Role);
                HttpContext.Session.SetString("UserName", user.FullName);

                return user.Role switch
                {
                    "Admin" => RedirectToAction("Dashboard", "Admin"),
                    "Student" => RedirectToAction("Dashboard", "Student"),
                    "Driver" => RedirectToAction("Dashboard", "Driver"),
                    _ => RedirectToAction("Login")
                };
            }

            ModelState.AddModelError("", "Invalid email or password.");
            return View(model);
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            if (_service.GetUserByEmail(model.Email) != null)
            {
                ModelState.AddModelError("", "Email already registered.");
                return View(model);
            }

            var user = new User
            {
                FullName = model.FullName,
                Email = model.Email,
                PasswordHash = model.Password,
                Role = "Student",
                PhoneNumber = model.PhoneNumber
            };

            var student = new Student
            {
                RegistrationNumber = model.RegistrationNumber,
                Department = model.Department,
                Year = model.Year,
                Address = model.Address
            };

            try
            {
                _service.AddStudent(student, user);
                TempData["Success"] = "Registration successful! Please log in.";
                return RedirectToAction("Login");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(model);
            }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }

        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}