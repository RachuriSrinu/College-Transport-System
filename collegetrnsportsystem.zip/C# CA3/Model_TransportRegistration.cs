namespace CollegeTransportSystem.Models
{
    public class TransportRegistration
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int RouteId { get; set; }
        public int BoardingStopId { get; set; }
        public DateTime RegistrationDate { get; set; }
        public string Status { get; set; } = "Pending";

        public Student Student { get; set; } = null!;
        public Route Route { get; set; } = null!;
        public BusStop BoardingStop { get; set; } = null!;
    }
}