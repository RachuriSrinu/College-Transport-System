using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc.Razor;
using CollegeTransportSystem.Data;
using CollegeTransportSystem.Services;
using CollegeTransportSystem.Models;
using ModelRoute = CollegeTransportSystem.Models.Route;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews(options =>
{
    // No special options needed
});

builder.Services.Configure<RazorViewEngineOptions>(options =>
{
    options.ViewLocationFormats.Clear();
    options.ViewLocationFormats.Add("/{0}.cshtml");
    options.ViewLocationFormats.Add("/Views_{1}_{0}.cshtml");
    options.ViewLocationFormats.Add("/Views_Shared/{0}.cshtml");
    options.ViewLocationFormats.Add("/Views_Shared/{1}_{0}.cshtml");
    options.ViewLocationFormats.Add("/{1}/{0}.cshtml");
    options.ViewLocationFormats.Add("/{1}/{0}.cshtml");
});

builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

builder.Services.AddScoped<ITransportService, TransportService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseSession();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Account}/{action=Login}/{id?}");

app.MapControllers(); // Required for [ApiController] routes

// Ensure database is created and seed data
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    context.Database.EnsureCreated();

    // Seed data
    if (!context.Users.Any())
    {
        // Admin user
        var adminUser = new User
        {
            FullName = "System Administrator",
            Email = "admin@college.edu",
            PasswordHash = BCryptHash("admin123"),
            Role = "Admin",
            PhoneNumber = "1234567890"
        };
        context.Users.Add(adminUser);
        context.SaveChanges();

        // Student user
        var studentUser = new User
        {
            FullName = "John Student",
            Email = "student@college.edu",
            PasswordHash = BCryptHash("student123"),
            Role = "Student",
            PhoneNumber = "1234567891"
        };
        context.Users.Add(studentUser);
        context.SaveChanges();

        var student = new Student
        {
            UserId = studentUser.Id,
            RegistrationNumber = "STU001",
            Department = "Computer Science",
            Year = 2,
            Address = "123 College Street, Campus"
        };
        context.Students.Add(student);
        context.SaveChanges();

        // Driver user
        var driverUser = new User
        {
            FullName = "Mike Driver",
            Email = "driver@college.edu",
            PasswordHash = BCryptHash("driver123"),
            Role = "Driver",
            PhoneNumber = "1234567892"
        };
        context.Users.Add(driverUser);
        context.SaveChanges();

        var driver = new Driver
        {
            UserId = driverUser.Id,
            LicenseNumber = "DL123456",
            Experience = 5
        };
        context.Drivers.Add(driver);
        context.SaveChanges();

        // Buses
        context.Buses.AddRange(
            new Bus { BusNumber = "BUS001", RegistrationNumber = "REG1001", Capacity = 40, Status = "Active" },
            new Bus { BusNumber = "BUS002", RegistrationNumber = "REG1002", Capacity = 35, Status = "Active" },
            new Bus { BusNumber = "BUS003", RegistrationNumber = "REG1003", Capacity = 50, Status = "Maintenance" }
        );
        context.SaveChanges();

        // Routes
        context.Routes.AddRange(
            new ModelRoute { RouteName = "North Campus Route", StartingPoint = "Main Gate", Destination = "North Campus", Distance = 15.5, MonthlyFee = 500 },
            new ModelRoute { RouteName = "South Campus Route", StartingPoint = "Main Gate", Destination = "South Campus", Distance = 20.0, MonthlyFee = 600 },
            new ModelRoute { RouteName = "City Center Route", StartingPoint = "City Center", Destination = "College Campus", Distance = 25.0, MonthlyFee = 700 }
        );
        context.SaveChanges();

        // Bus Stops
        context.BusStops.AddRange(
            new BusStop { StopName = "Main Gate", Latitude = 40.7128, Longitude = -74.0060, RouteId = 1 },
            new BusStop { StopName = "City Library", Latitude = 40.7138, Longitude = -74.0050, RouteId = 1 },
            new BusStop { StopName = "North Campus", Latitude = 40.7158, Longitude = -74.0040, RouteId = 1 },
            new BusStop { StopName = "Main Gate", Latitude = 40.7128, Longitude = -74.0060, RouteId = 2 },
            new BusStop { StopName = "Shopping Mall", Latitude = 40.7148, Longitude = -74.0070, RouteId = 2 },
            new BusStop { StopName = "South Campus", Latitude = 40.7168, Longitude = -74.0080, RouteId = 2 }
        );
        context.SaveChanges();

        // Route Assignment
        context.RouteAssignments.Add(new RouteAssignment
        {
            BusId = 1,
            DriverId = 1,
            RouteId = 1
        });
        context.SaveChanges();

        // Transport Registration
        context.TransportRegistrations.Add(new TransportRegistration
        {
            StudentId = 1,
            RouteId = 1,
            BoardingStopId = 1,
            RegistrationDate = DateTime.Now,
            Status = "Approved"
        });
        context.SaveChanges();

        // Bus Pass
        context.BusPasses.Add(new BusPass
        {
            StudentId = 1,
            RouteId = 1,
            PassNumber = "BP2026010001",
            IssueDate = DateTime.Now.AddMonths(-1),
            ExpiryDate = DateTime.Now.AddMonths(1),
            Status = "Active"
        });
        context.SaveChanges();

        // Payment
        context.Payments.Add(new Payment
        {
            StudentId = 1,
            Amount = 500,
            PaymentDate = DateTime.Now.AddMonths(-1),
            PaymentMethod = "Online",
            Status = "Paid"
        });
        context.SaveChanges();

        // Absence Report
        context.AbsenceReports.Add(new AbsenceReport
        {
            StudentId = 1,
            AbsenceDate = DateTime.Now.AddDays(-2),
            Reason = "Medical appointment",
            Status = "Approved"
        });
        context.SaveChanges();
    }
}

app.Run();

string BCryptHash(string password)
{
    // Simple PBKDF2 hash
    byte[] salt = new byte[128 / 8];
    using var rng = System.Security.Cryptography.RandomNumberGenerator.Create();
    rng.GetBytes(salt);
    string hashed = Convert.ToBase64String(Microsoft.AspNetCore.Cryptography.KeyDerivation.KeyDerivation.Pbkdf2(
        password: password,
        salt: salt,
        prf: Microsoft.AspNetCore.Cryptography.KeyDerivation.KeyDerivationPrf.HMACSHA256,
        iterationCount: 10000,
        numBytesRequested: 256 / 8));
    return $"{Convert.ToBase64String(salt)}:{hashed}";
}