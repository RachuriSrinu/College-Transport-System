namespace CollegeTransportSystem.Models
{
    public class BusStop
    {
        public int Id { get; set; }
        public string StopName { get; set; } = string.Empty;
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public int RouteId { get; set; }

        public Route Route { get; set; } = null!;
    }
}