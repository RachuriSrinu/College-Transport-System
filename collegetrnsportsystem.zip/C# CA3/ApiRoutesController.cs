using Microsoft.AspNetCore.Mvc;
using CollegeTransportSystem.Services;

namespace CollegeTransportSystem.Controllers
{
    [ApiController]
    [Route("api/routes")]
    public class ApiRoutesController : ControllerBase
    {
        private readonly ITransportService _service;

        public ApiRoutesController(ITransportService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetRoutes()
        {
            var routes = _service.GetApiRoutes();
            return Ok(routes);
        }

        [HttpGet("{id}/stops")]
        public IActionResult GetStops(int id)
        {
            var stops = _service.GetApiRouteStops(id);
            return Ok(stops);
        }

        [HttpGet("{id}/students")]
        public IActionResult GetStudents(int id)
        {
            var students = _service.GetApiRouteStudents(id);
            return Ok(students);
        }
    }
}