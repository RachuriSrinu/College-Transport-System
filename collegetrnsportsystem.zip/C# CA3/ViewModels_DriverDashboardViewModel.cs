using CollegeTransportSystem.Models;
using ModelRoute = CollegeTransportSystem.Models.Route;

namespace CollegeTransportSystem.ViewModels
{
    public class DriverDashboardViewModel
    {
        public Driver Driver { get; set; } = null!;
        public Bus? AssignedBus { get; set; }
        public ModelRoute? AssignedRoute { get; set; }
        public List<BusStop> RouteStops { get; set; } = new();
        public List<Student> RegisteredStudents { get; set; } = new();
        public List<AbsenceReport> AbsenceReports { get; set; } = new();
    }
}