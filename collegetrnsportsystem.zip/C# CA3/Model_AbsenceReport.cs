namespace CollegeTransportSystem.Models
{
    public class AbsenceReport
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public DateTime AbsenceDate { get; set; }
        public string Reason { get; set; } = string.Empty;
        public string Status { get; set; } = "Pending";

        public Student Student { get; set; } = null!;
    }
}