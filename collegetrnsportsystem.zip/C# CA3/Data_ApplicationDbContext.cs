using Microsoft.EntityFrameworkCore;
using CollegeTransportSystem.Models;
using ModelRoute = CollegeTransportSystem.Models.Route;

namespace CollegeTransportSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Student> Students { get; set; }
        public DbSet<Driver> Drivers { get; set; }
        public DbSet<Bus> Buses { get; set; }
        public DbSet<ModelRoute> Routes { get; set; }
        public DbSet<BusStop> BusStops { get; set; }
        public DbSet<RouteAssignment> RouteAssignments { get; set; }
        public DbSet<TransportRegistration> TransportRegistrations { get; set; }
        public DbSet<BusPass> BusPasses { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<AbsenceReport> AbsenceReports { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasIndex(e => e.Email).IsUnique();
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasIndex(e => e.RegistrationNumber).IsUnique();
                entity.HasOne(s => s.User)
                    .WithMany()
                    .HasForeignKey(s => s.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<Driver>(entity =>
            {
                entity.HasIndex(e => e.LicenseNumber).IsUnique();
                entity.HasOne(d => d.User)
                    .WithMany()
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<BusStop>(entity =>
            {
                entity.HasOne(bs => bs.Route)
                    .WithMany(r => r.BusStops!)
                    .HasForeignKey(bs => bs.RouteId)
                    .OnDelete(DeleteBehavior.Cascade);
            });

            modelBuilder.Entity<RouteAssignment>(entity =>
            {
                entity.HasOne(ra => ra.Bus)
                    .WithMany()
                    .HasForeignKey(ra => ra.BusId);
                entity.HasOne(ra => ra.Driver)
                    .WithMany()
                    .HasForeignKey(ra => ra.DriverId);
                entity.HasOne(ra => ra.Route)
                    .WithMany()
                    .HasForeignKey(ra => ra.RouteId);
            });

            modelBuilder.Entity<TransportRegistration>(entity =>
            {
                entity.HasOne(tr => tr.Student)
                    .WithMany()
                    .HasForeignKey(tr => tr.StudentId)
                    .OnDelete(DeleteBehavior.Cascade);
                entity.HasOne(tr => tr.Route)
                    .WithMany()
                    .HasForeignKey(tr => tr.RouteId)
                    .OnDelete(DeleteBehavior.NoAction);
                entity.HasOne(tr => tr.BoardingStop)
                    .WithMany()
                    .HasForeignKey(tr => tr.BoardingStopId)
                    .OnDelete(DeleteBehavior.NoAction);
            });

            modelBuilder.Entity<BusPass>(entity =>
            {
                entity.HasIndex(e => e.PassNumber).IsUnique();
                entity.HasOne(bp => bp.Student)
                    .WithMany()
                    .HasForeignKey(bp => bp.StudentId);
                entity.HasOne(bp => bp.Route)
                    .WithMany()
                    .HasForeignKey(bp => bp.RouteId);
            });

            modelBuilder.Entity<Payment>(entity =>
            {
                entity.HasOne(p => p.Student)
                    .WithMany()
                    .HasForeignKey(p => p.StudentId);
            });

            modelBuilder.Entity<AbsenceReport>(entity =>
            {
                entity.HasOne(ar => ar.Student)
                    .WithMany()
                    .HasForeignKey(ar => ar.StudentId);
            });
        }
    }
}