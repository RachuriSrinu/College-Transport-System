using Microsoft.AspNetCore.Mvc;
using CollegeTransportSystem.Services;

namespace CollegeTransportSystem.Controllers
{
    [ApiController]
    [Route("api/absences")]
    public class ApiAbsencesController : ControllerBase
    {
        private readonly ITransportService _service;

        public ApiAbsencesController(ITransportService service)
        {
            _service = service;
        }

        [HttpGet]
        public IActionResult GetAbsences()
        {
            var absences = _service.GetApiAbsences();
            return Ok(absences);
        }
    }
}