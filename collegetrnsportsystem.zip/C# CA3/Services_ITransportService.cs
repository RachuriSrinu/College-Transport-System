using CollegeTransportSystem.Models;
using CollegeTransportSystem.ViewModels;
using ModelRoute = CollegeTransportSystem.Models.Route;

namespace CollegeTransportSystem.Services
{
    public interface ITransportService
    {
        // Dashboard
        DashboardViewModel GetDashboardStats();

        // Users
        User? GetUserByEmail(string email);
        User? GetUserById(int id);
        bool ValidateUser(string email, string password);
        void CreateUser(User user, string password);
        string HashPassword(string password);

        // Students
        List<Student> GetAllStudents();
        Student? GetStudentById(int id);
        void AddStudent(Student student, User user);
        void UpdateStudent(Student student);
        void DeleteStudent(int id);

        // Drivers
        List<Driver> GetAllDrivers();
        Driver? GetDriverById(int id);
        void AddDriver(Driver driver, User user);
        void UpdateDriver(Driver driver);
        void DeleteDriver(int id);

        // Buses
        List<Bus> GetAllBuses();
        Bus? GetBusById(int id);
        void AddBus(Bus bus);
        void UpdateBus(Bus bus);
        void DeleteBus(int id);

        // Routes
        List<ModelRoute> GetAllRoutes();
        ModelRoute? GetRouteById(int id);
        void AddRoute(ModelRoute route);
        void UpdateRoute(ModelRoute route);
        void DeleteRoute(int id);

        // Bus Stops
        List<BusStop> GetStopsByRouteId(int routeId);
        void AddBusStop(BusStop stop);
        void DeleteBusStop(int id);

        // Route Assignments
        List<RouteAssignment> GetAllRouteAssignments();
        RouteAssignment? GetRouteAssignmentById(int id);
        void AddRouteAssignment(RouteAssignment assignment);
        void DeleteRouteAssignment(int id);

        // Registrations
        List<TransportRegistration> GetAllRegistrations();
        TransportRegistration? GetRegistrationById(int id);
        TransportRegistration? GetRegistrationByStudentId(int studentId);
        void AddRegistration(TransportRegistration registration);
        void UpdateRegistrationStatus(int id, string status);
        void DeleteRegistration(int id);

        // Bus Passes
        List<BusPass> GetAllBusPasses();
        BusPass? GetBusPassById(int id);
        BusPass? GetBusPassByStudentId(int studentId);
        void GenerateBusPass(int studentId, int routeId);

        // Payments
        List<Payment> GetAllPayments();
        Payment? GetPaymentById(int id);
        List<Payment> GetPaymentsByStudentId(int studentId);
        void AddPayment(Payment payment);
        void UpdatePaymentStatus(int id, string status);

        // Absence Reports
        List<AbsenceReport> GetAllAbsenceReports();
        AbsenceReport? GetAbsenceReportById(int id);
        List<AbsenceReport> GetAbsenceReportsByStudentId(int studentId);
        void AddAbsenceReport(AbsenceReport report);
        void UpdateAbsenceReportStatus(int id, string status);

        // API
        List<ModelRoute> GetApiRoutes();
        List<Bus> GetApiBuses();
        List<RouteAssignment> GetApiDriverAssignments(int driverId);
        List<BusStop> GetApiRouteStops(int routeId);
        List<Student> GetApiRouteStudents(int routeId);
        List<BusPass> GetApiStudentPasses(int studentId);
        List<AbsenceReport> GetApiAbsences();
    }
}