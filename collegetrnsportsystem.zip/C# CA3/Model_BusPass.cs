namespace CollegeTransportSystem.Models
{
    public class BusPass
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int RouteId { get; set; }
        public string PassNumber { get; set; } = string.Empty;
        public DateTime IssueDate { get; set; }
        public DateTime ExpiryDate { get; set; }
        public string Status { get; set; } = "Active";

        public Student Student { get; set; } = null!;
        public Route Route { get; set; } = null!;
    }
}