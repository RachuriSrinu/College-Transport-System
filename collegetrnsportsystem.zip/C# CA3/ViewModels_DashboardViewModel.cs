namespace CollegeTransportSystem.ViewModels
{
    public class DashboardViewModel
    {
        public int TotalStudents { get; set; }
        public int TotalBuses { get; set; }
        public int TotalDrivers { get; set; }
        public int TotalRoutes { get; set; }
        public int ActiveBusPasses { get; set; }
        public int PendingRegistrations { get; set; }
        public decimal TotalFeeCollection { get; set; }
    }
}