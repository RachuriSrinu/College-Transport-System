namespace CollegeTransportSystem.Models
{
    public class Driver
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public string LicenseNumber { get; set; } = string.Empty;
        public int Experience { get; set; }

        public User User { get; set; } = null!;
    }
}