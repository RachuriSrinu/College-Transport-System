using CollegeTransportSystem.Models;
using ModelRoute = CollegeTransportSystem.Models.Route;

namespace CollegeTransportSystem.ViewModels
{
    public class BusPassViewModel
    {
        public BusPass BusPass { get; set; } = null!;
        public Student Student { get; set; } = null!;
        public ModelRoute Route { get; set; } = null!;
        public Payment? Payment { get; set; }
    }
}