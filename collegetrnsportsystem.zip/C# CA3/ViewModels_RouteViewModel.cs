using CollegeTransportSystem.Models;

namespace CollegeTransportSystem.ViewModels
{
    public class RouteViewModel
    {
        public int Id { get; set; }
        public string RouteName { get; set; } = string.Empty;
        public string StartingPoint { get; set; } = string.Empty;
        public string Destination { get; set; } = string.Empty;
        public double Distance { get; set; }
        public decimal MonthlyFee { get; set; }
        public List<BusStop> BusStops { get; set; } = new();
    }
}