using Microsoft.AspNetCore.Mvc;
using CollegeTransportSystem.Models;
using CollegeTransportSystem.Services;
using CollegeTransportSystem.ViewModels;

namespace CollegeTransportSystem
{
    public class DriverController : Controller
    {
        private readonly ITransportService _service;

        public DriverController(ITransportService service)
        {
            _service = service;
        }

        private bool IsDriver() => HttpContext.Session.GetString("UserRole") == "Driver";

        private IActionResult CheckDriver()
        {
            if (!IsDriver()) return RedirectToAction("AccessDenied", "Account");
            return null!;
        }

        private int GetCurrentDriverId()
        {
            var userId = HttpContext.Session.GetInt32("UserId") ?? 0;
            var driver = _service.GetAllDrivers().FirstOrDefault(d => d.UserId == userId);
            return driver?.Id ?? 0;
        }

        public IActionResult Dashboard()
        {
            var check = CheckDriver();
            if (check != null) return check;

            var driverId = GetCurrentDriverId();
            var driver = _service.GetDriverById(driverId);
            if (driver == null) return NotFound();

            var assignment = _service.GetAllRouteAssignments()
                .FirstOrDefault(ra => ra.DriverId == driverId);

            var model = new DriverDashboardViewModel
            {
                Driver = driver,
                AssignedBus = assignment?.Bus,
                AssignedRoute = assignment?.Route,
                RouteStops = assignment != null ? _service.GetStopsByRouteId(assignment.RouteId) : new List<BusStop>(),
                RegisteredStudents = _service.GetAllStudents(),
                AbsenceReports = _service.GetAllAbsenceReports()
            };

            return View(model);
        }
    }
}