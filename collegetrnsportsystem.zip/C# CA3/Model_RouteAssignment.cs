namespace CollegeTransportSystem.Models
{
    public class RouteAssignment
    {
        public int Id { get; set; }
        public int BusId { get; set; }
        public int DriverId { get; set; }
        public int RouteId { get; set; }

        public Bus Bus { get; set; } = null!;
        public Driver Driver { get; set; } = null!;
        public Route Route { get; set; } = null!;
    }
}