using Microsoft.AspNetCore.Mvc;
using CollegeTransportSystem.Models;
using CollegeTransportSystem.Services;
using CollegeTransportSystem.ViewModels;
using ModelRoute = CollegeTransportSystem.Models.Route;

namespace CollegeTransportSystem
{
    public class AdminController : Controller
    {
        private readonly ITransportService _service;

        public AdminController(ITransportService service)
        {
            _service = service;
        }

        private bool IsAdmin() => HttpContext.Session.GetString("UserRole") == "Admin";

        private IActionResult CheckAdmin()
        {
            if (!IsAdmin()) return RedirectToAction("AccessDenied", "Account");
            return null!;
        }

        public IActionResult Dashboard()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var stats = _service.GetDashboardStats();
            return View(stats);
        }

        public IActionResult Students()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var students = _service.GetAllStudents();
            return View(students);
        }

        public IActionResult AddStudent()
        {
            var check = CheckAdmin();
            if (check != null) return check;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddStudent(RegisterViewModel model)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            if (!ModelState.IsValid) return View(model);

            if (_service.GetUserByEmail(model.Email) != null)
            {
                ModelState.AddModelError("", "Email already registered.");
                return View(model);
            }

            var user = new User
            {
                FullName = model.FullName,
                Email = model.Email,
                PasswordHash = model.Password,
                Role = "Student",
                PhoneNumber = model.PhoneNumber
            };

            var student = new Student
            {
                RegistrationNumber = model.RegistrationNumber,
                Department = model.Department,
                Year = model.Year,
                Address = model.Address
            };

            try
            {
                _service.AddStudent(student, user);
                TempData["Success"] = "Student added successfully.";
                return RedirectToAction("Students");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(model);
            }
        }

        public IActionResult EditStudent(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var student = _service.GetStudentById(id);
            if (student == null) return NotFound();

            var model = new RegisterViewModel
            {
                FullName = student.User?.FullName ?? string.Empty,
                Email = student.User?.Email ?? string.Empty,
                PhoneNumber = student.User?.PhoneNumber ?? string.Empty,
                RegistrationNumber = student.RegistrationNumber,
                Department = student.Department,
                Year = student.Year,
                Address = student.Address
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditStudent(int id, RegisterViewModel model)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            if (!ModelState.IsValid) return View(model);

            var student = _service.GetStudentById(id);
            if (student == null) return NotFound();

            student.RegistrationNumber = model.RegistrationNumber;
            student.Department = model.Department;
            student.Year = model.Year;
            student.Address = model.Address;

            if (student.User != null)
            {
                student.User.FullName = model.FullName;
                student.User.Email = model.Email;
                student.User.PhoneNumber = model.PhoneNumber;
            }

            _service.UpdateStudent(student);
            TempData["Success"] = "Student updated successfully.";
            return RedirectToAction("Students");
        }

        public IActionResult DeleteStudent(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.DeleteStudent(id);
            TempData["Success"] = "Student deleted successfully.";
            return RedirectToAction("Students");
        }

        // Drivers
        public IActionResult Drivers()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var drivers = _service.GetAllDrivers();
            return View(drivers);
        }

        public IActionResult AddDriver()
        {
            var check = CheckAdmin();
            if (check != null) return check;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddDriver(RegisterViewModel model)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            if (!ModelState.IsValid) return View(model);

            var user = new User
            {
                FullName = model.FullName,
                Email = model.Email,
                PasswordHash = model.Password,
                Role = "Driver",
                PhoneNumber = model.PhoneNumber
            };

            var driver = new Driver
            {
                LicenseNumber = model.RegistrationNumber,
                Experience = model.Year
            };

            try
            {
                _service.AddDriver(driver, user);
                TempData["Success"] = "Driver added successfully.";
                return RedirectToAction("Drivers");
            }
            catch (Exception ex)
            {
                ModelState.AddModelError("", ex.Message);
                return View(model);
            }
        }

        public IActionResult EditDriver(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var driver = _service.GetDriverById(id);
            if (driver == null) return NotFound();

            var model = new RegisterViewModel
            {
                FullName = driver.User?.FullName ?? string.Empty,
                Email = driver.User?.Email ?? string.Empty,
                PhoneNumber = driver.User?.PhoneNumber ?? string.Empty,
                RegistrationNumber = driver.LicenseNumber,
                Year = driver.Experience
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditDriver(int id, RegisterViewModel model)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            if (!ModelState.IsValid) return View(model);

            var driver = _service.GetDriverById(id);
            if (driver == null) return NotFound();

            driver.LicenseNumber = model.RegistrationNumber;
            driver.Experience = model.Year;

            if (driver.User != null)
            {
                driver.User.FullName = model.FullName;
                driver.User.Email = model.Email;
                driver.User.PhoneNumber = model.PhoneNumber;
            }

            _service.UpdateDriver(driver);
            TempData["Success"] = "Driver updated successfully.";
            return RedirectToAction("Drivers");
        }

        public IActionResult DeleteDriver(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.DeleteDriver(id);
            TempData["Success"] = "Driver deleted successfully.";
            return RedirectToAction("Drivers");
        }

        // Buses
        public IActionResult Buses()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var buses = _service.GetAllBuses();
            return View(buses);
        }

        public IActionResult AddBus()
        {
            var check = CheckAdmin();
            if (check != null) return check;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddBus(Bus model)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            if (!ModelState.IsValid) return View(model);
            _service.AddBus(model);
            TempData["Success"] = "Bus added successfully.";
            return RedirectToAction("Buses");
        }

        public IActionResult EditBus(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var bus = _service.GetBusById(id);
            if (bus == null) return NotFound();
            return View(bus);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditBus(int id, Bus model)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            if (!ModelState.IsValid) return View(model);
            _service.UpdateBus(model);
            TempData["Success"] = "Bus updated successfully.";
            return RedirectToAction("Buses");
        }

        public IActionResult DeleteBus(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.DeleteBus(id);
            TempData["Success"] = "Bus deleted successfully.";
            return RedirectToAction("Buses");
        }

        // Routes
        public IActionResult Routes()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var routes = _service.GetAllRoutes();
            return View(routes);
        }

        public IActionResult AddRoute()
        {
            var check = CheckAdmin();
            if (check != null) return check;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddRoute(ModelRoute model)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            if (!ModelState.IsValid) return View(model);
            _service.AddRoute(model);
            TempData["Success"] = "Route added successfully.";
            return RedirectToAction("Routes");
        }

        public IActionResult EditRoute(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var route = _service.GetRouteById(id);
            if (route == null) return NotFound();
            return View(route);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult EditRoute(int id, ModelRoute model)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            if (!ModelState.IsValid) return View(model);
            _service.UpdateRoute(model);
            TempData["Success"] = "Route updated successfully.";
            return RedirectToAction("Routes");
        }

        public IActionResult DeleteRoute(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.DeleteRoute(id);
            TempData["Success"] = "Route deleted successfully.";
            return RedirectToAction("Routes");
        }

        public IActionResult RouteStops(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var route = _service.GetRouteById(id);
            if (route == null) return NotFound();

            var stops = _service.GetStopsByRouteId(id);
            var model = new RouteViewModel
            {
                Id = route.Id,
                RouteName = route.RouteName,
                StartingPoint = route.StartingPoint,
                Destination = route.Destination,
                Distance = route.Distance,
                MonthlyFee = route.MonthlyFee,
                BusStops = stops
            };
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddBusStop(int routeId, string stopName, double latitude, double longitude)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var stop = new BusStop
            {
                StopName = stopName,
                Latitude = latitude,
                Longitude = longitude,
                RouteId = routeId
            };
            _service.AddBusStop(stop);
            TempData["Success"] = "Bus stop added successfully.";
            return RedirectToAction("RouteStops", new { id = routeId });
        }

        public IActionResult DeleteBusStop(int id, int routeId)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.DeleteBusStop(id);
            TempData["Success"] = "Bus stop deleted successfully.";
            return RedirectToAction("RouteStops", new { id = routeId });
        }

        // Route Assignments
        public IActionResult RouteAssignments()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var assignments = _service.GetAllRouteAssignments();
            return View(assignments);
        }

        public IActionResult AddRouteAssignment()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            ViewBag.Buses = _service.GetAllBuses();
            ViewBag.Drivers = _service.GetAllDrivers();
            ViewBag.Routes = _service.GetAllRoutes();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AddRouteAssignment(RouteAssignment model)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            try
            {
                _service.AddRouteAssignment(model);
                TempData["Success"] = "Route assignment created successfully.";
                return RedirectToAction("RouteAssignments");
            }
            catch (InvalidOperationException ex)
            {
                ModelState.AddModelError("", ex.Message);
                ViewBag.Buses = _service.GetAllBuses();
                ViewBag.Drivers = _service.GetAllDrivers();
                ViewBag.Routes = _service.GetAllRoutes();
                return View(model);
            }
        }

        public IActionResult DeleteRouteAssignment(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.DeleteRouteAssignment(id);
            TempData["Success"] = "Route assignment deleted successfully.";
            return RedirectToAction("RouteAssignments");
        }

        // Registrations
        public IActionResult Registrations()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var registrations = _service.GetAllRegistrations();
            return View(registrations);
        }

        public IActionResult ApproveRegistration(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.UpdateRegistrationStatus(id, "Approved");
            TempData["Success"] = "Registration approved.";
            return RedirectToAction("Registrations");
        }

        public IActionResult RejectRegistration(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.UpdateRegistrationStatus(id, "Rejected");
            TempData["Success"] = "Registration rejected.";
            return RedirectToAction("Registrations");
        }

        // Bus Passes
        public IActionResult BusPasses()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var passes = _service.GetAllBusPasses();
            return View(passes);
        }

        public IActionResult GenerateBusPass(int studentId, int routeId)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.GenerateBusPass(studentId, routeId);
            TempData["Success"] = "Bus pass generated successfully.";
            return RedirectToAction("BusPasses");
        }

        // Payments
        public IActionResult Payments()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var payments = _service.GetAllPayments();
            return View(payments);
        }

        public IActionResult MarkPaymentPaid(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.UpdatePaymentStatus(id, "Paid");
            TempData["Success"] = "Payment marked as paid.";
            return RedirectToAction("Payments");
        }

        // Absence Reports
        public IActionResult AbsenceReports()
        {
            var check = CheckAdmin();
            if (check != null) return check;

            var reports = _service.GetAllAbsenceReports();
            return View(reports);
        }

        public IActionResult ApproveAbsence(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.UpdateAbsenceReportStatus(id, "Approved");
            TempData["Success"] = "Absence report approved.";
            return RedirectToAction("AbsenceReports");
        }

        public IActionResult RejectAbsence(int id)
        {
            var check = CheckAdmin();
            if (check != null) return check;

            _service.UpdateAbsenceReportStatus(id, "Rejected");
            TempData["Success"] = "Absence report rejected.";
            return RedirectToAction("AbsenceReports");
        }
    }
}