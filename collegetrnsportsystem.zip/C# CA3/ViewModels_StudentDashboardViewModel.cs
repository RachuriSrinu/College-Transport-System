using CollegeTransportSystem.Models;
using ModelRoute = CollegeTransportSystem.Models.Route;

namespace CollegeTransportSystem.ViewModels
{
    public class StudentDashboardViewModel
    {
        public Student Student { get; set; } = null!;
        public TransportRegistration? Registration { get; set; }
        public BusPass? BusPass { get; set; }
        public List<ModelRoute> AvailableRoutes { get; set; } = new();
        public List<Payment> PaymentHistory { get; set; } = new();
        public List<AbsenceReport> AbsenceReports { get; set; } = new();
        public decimal MonthlyFee { get; set; }
    }
}