using CollegeTransportSystem.Data;
using CollegeTransportSystem.Models;
using CollegeTransportSystem.ViewModels;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;
using System.Security.Cryptography;
using ModelRoute = CollegeTransportSystem.Models.Route;

namespace CollegeTransportSystem.Services
{
    public class TransportService : ITransportService
    {
        private readonly ApplicationDbContext _context;

        public TransportService(ApplicationDbContext context)
        {
            _context = context;
        }

        public string HashPassword(string password)
        {
            byte[] salt = new byte[128 / 8];
            using var rng = RandomNumberGenerator.Create();
            rng.GetBytes(salt);
            string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));
            return $"{Convert.ToBase64String(salt)}:{hashed}";
        }

        public bool ValidateUser(string email, string password)
        {
            var user = _context.Users.FirstOrDefault(u => u.Email == email);
            if (user == null) return false;
            var parts = user.PasswordHash.Split(':');
            if (parts.Length != 2) return false;
            var salt = Convert.FromBase64String(parts[0]);
            var hash = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));
            return hash == parts[1];
        }

        public void CreateUser(User user, string password)
        {
            user.PasswordHash = HashPassword(password);
            _context.Users.Add(user);
            _context.SaveChanges();
        }

        public User? GetUserByEmail(string email) =>
            _context.Users.FirstOrDefault(u => u.Email == email);

        public User? GetUserById(int id) =>
            _context.Users.FirstOrDefault(u => u.Id == id);

        public DashboardViewModel GetDashboardStats()
        {
            return new DashboardViewModel
            {
                TotalStudents = _context.Students.Count(),
                TotalBuses = _context.Buses.Count(),
                TotalDrivers = _context.Drivers.Count(),
                TotalRoutes = _context.Routes.Count(),
                ActiveBusPasses = _context.BusPasses.Count(bp => bp.Status == "Active"),
                PendingRegistrations = _context.TransportRegistrations.Count(tr => tr.Status == "Pending"),
                TotalFeeCollection = _context.Payments.Where(p => p.Status == "Paid").Sum(p => p.Amount)
            };
        }

        public List<Student> GetAllStudents() =>
            _context.Students.Include(s => s.User).ToList();

        public Student? GetStudentById(int id) =>
            _context.Students.Include(s => s.User).FirstOrDefault(s => s.Id == id);

        public void AddStudent(Student student, User user)
        {
            user.Role = "Student";
            CreateUser(user, user.PasswordHash);
            _context.Students.Add(student);
            _context.SaveChanges();
        }

        public void UpdateStudent(Student student)
        {
            _context.Students.Update(student);
            _context.SaveChanges();
        }

        public void DeleteStudent(int id)
        {
            var student = _context.Students.Find(id);
            if (student != null)
            {
                var user = _context.Users.Find(student.UserId);
                _context.Students.Remove(student);
                if (user != null) _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }

        public List<Driver> GetAllDrivers() =>
            _context.Drivers.Include(d => d.User).ToList();

        public Driver? GetDriverById(int id) =>
            _context.Drivers.Include(d => d.User).FirstOrDefault(d => d.Id == id);

        public void AddDriver(Driver driver, User user)
        {
            user.Role = "Driver";
            CreateUser(user, user.PasswordHash);
            _context.Drivers.Add(driver);
            _context.SaveChanges();
        }

        public void UpdateDriver(Driver driver)
        {
            _context.Drivers.Update(driver);
            _context.SaveChanges();
        }

        public void DeleteDriver(int id)
        {
            var driver = _context.Drivers.Find(id);
            if (driver != null)
            {
                var user = _context.Users.Find(driver.UserId);
                _context.Drivers.Remove(driver);
                if (user != null) _context.Users.Remove(user);
                _context.SaveChanges();
            }
        }

        public List<Bus> GetAllBuses() => _context.Buses.ToList();
        public Bus? GetBusById(int id) => _context.Buses.Find(id);

        public void AddBus(Bus bus)
        {
            _context.Buses.Add(bus);
            _context.SaveChanges();
        }
        public void UpdateBus(Bus bus)
        {
            _context.Buses.Update(bus);
            _context.SaveChanges();
        }
        public void DeleteBus(int id)
        {
            var bus = _context.Buses.Find(id);
            if (bus != null)
            {
                var assigned = _context.RouteAssignments.Any(ra => ra.BusId == id);
                if (!assigned)
                {
                    _context.Buses.Remove(bus);
                    _context.SaveChanges();
                }
            }
        }

        public List<ModelRoute> GetAllRoutes() => _context.Routes.Include(r => r.BusStops).ToList();
        public ModelRoute? GetRouteById(int id) => _context.Routes.Find(id);

        public void AddRoute(ModelRoute route)
        {
            _context.Routes.Add(route);
            _context.SaveChanges();
        }
        public void UpdateRoute(ModelRoute route)
        {
            _context.Routes.Update(route);
            _context.SaveChanges();
        }
        public void DeleteRoute(int id)
        {
            var route = _context.Routes.Find(id);
            if (route != null)
            {
                var stops = _context.BusStops.Where(bs => bs.RouteId == id).ToList();
                _context.BusStops.RemoveRange(stops);
                _context.Routes.Remove(route);
                _context.SaveChanges();
            }
        }

        public List<BusStop> GetStopsByRouteId(int routeId) =>
            _context.BusStops.Where(bs => bs.RouteId == routeId).ToList();

        public void AddBusStop(BusStop stop)
        {
            _context.BusStops.Add(stop);
            _context.SaveChanges();
        }

        public void DeleteBusStop(int id)
        {
            var stop = _context.BusStops.Find(id);
            if (stop != null)
            {
                _context.BusStops.Remove(stop);
                _context.SaveChanges();
            }
        }

        public List<RouteAssignment> GetAllRouteAssignments() =>
            _context.RouteAssignments
                .Include(ra => ra.Bus)
                .Include(ra => ra.Driver)
                .Include(ra => ra.Route)
                .ToList();

        public RouteAssignment? GetRouteAssignmentById(int id) =>
            _context.RouteAssignments.Find(id);

        public void AddRouteAssignment(RouteAssignment assignment)
        {
            var bus = _context.Buses.Find(assignment.BusId);
            var route = _context.Routes.Find(assignment.RouteId);
            if (bus != null && route != null)
            {
                var studentCount = _context.TransportRegistrations
                    .Count(tr => tr.RouteId == assignment.RouteId && tr.Status == "Approved");
                if (studentCount >= bus.Capacity)
                {
                    throw new InvalidOperationException("Bus capacity exceeded for this route.");
                }
            }
            _context.RouteAssignments.Add(assignment);
            _context.SaveChanges();
        }

        public void DeleteRouteAssignment(int id)
        {
            var assignment = _context.RouteAssignments.Find(id);
            if (assignment != null)
            {
                _context.RouteAssignments.Remove(assignment);
                _context.SaveChanges();
            }
        }

        public List<TransportRegistration> GetAllRegistrations() =>
            _context.TransportRegistrations
                .Include(tr => tr.Student)
                .Include(tr => tr.Route)
                .Include(tr => tr.BoardingStop)
                .ToList();

        public TransportRegistration? GetRegistrationById(int id) =>
            _context.TransportRegistrations.Find(id);

        public TransportRegistration? GetRegistrationByStudentId(int studentId) =>
            _context.TransportRegistrations.FirstOrDefault(tr => tr.StudentId == studentId);

        public void AddRegistration(TransportRegistration registration)
        {
            var existing = _context.TransportRegistrations
                .FirstOrDefault(tr => tr.StudentId == registration.StudentId &&
                                     (tr.Status == "Pending" || tr.Status == "Approved"));
            if (existing != null)
                throw new InvalidOperationException("You already have an active or pending registration.");

            registration.RegistrationDate = DateTime.Now;
            _context.TransportRegistrations.Add(registration);
            _context.SaveChanges();
        }

        public void UpdateRegistrationStatus(int id, string status)
        {
            var reg = _context.TransportRegistrations.Find(id);
            if (reg != null)
            {
                reg.Status = status;
                _context.SaveChanges();
            }
        }

        public void DeleteRegistration(int id)
        {
            var reg = _context.TransportRegistrations.Find(id);
            if (reg != null)
            {
                _context.TransportRegistrations.Remove(reg);
                _context.SaveChanges();
            }
        }

        public List<BusPass> GetAllBusPasses() =>
            _context.BusPasses.Include(bp => bp.Student).Include(bp => bp.Route).ToList();

        public BusPass? GetBusPassById(int id) => _context.BusPasses.Find(id);

        public BusPass? GetBusPassByStudentId(int studentId) => _context.BusPasses.FirstOrDefault(bp => bp.StudentId == studentId);

        public void GenerateBusPass(int studentId, int routeId)
        {
            var student = _context.Students.Find(studentId);
            var route = _context.Routes.Find(routeId);
            if (student == null || route == null) return;

            var passNumber = $"BP{DateTime.Now:yyyyMMdd}{studentId:0000}";
            var pass = new BusPass
            {
                StudentId = studentId,
                RouteId = routeId,
                PassNumber = passNumber,
                IssueDate = DateTime.Now,
                ExpiryDate = DateTime.Now.AddMonths(1),
                Status = "Active"
            };
            _context.BusPasses.Add(pass);
            _context.SaveChanges();
        }

        public List<Payment> GetAllPayments() =>
            _context.Payments.Include(p => p.Student).ToList();

        public Payment? GetPaymentById(int id) => _context.Payments.Find(id);

        public List<Payment> GetPaymentsByStudentId(int studentId) =>
            _context.Payments.Where(p => p.StudentId == studentId).ToList();

        public void AddPayment(Payment payment)
        {
            _context.Payments.Add(payment);
            _context.SaveChanges();
        }

        public void UpdatePaymentStatus(int id, string status)
        {
            var payment = _context.Payments.Find(id);
            if (payment != null)
            {
                payment.Status = status;
                _context.SaveChanges();
            }
        }

        public List<AbsenceReport> GetAllAbsenceReports() =>
            _context.AbsenceReports.Include(ar => ar.Student).ToList();

        public AbsenceReport? GetAbsenceReportById(int id) => _context.AbsenceReports.Find(id);

        public List<AbsenceReport> GetAbsenceReportsByStudentId(int studentId) =>
            _context.AbsenceReports.Where(ar => ar.StudentId == studentId).ToList();

        public void AddAbsenceReport(AbsenceReport report)
        {
            _context.AbsenceReports.Add(report);
            _context.SaveChanges();
        }

        public void UpdateAbsenceReportStatus(int id, string status)
        {
            var report = _context.AbsenceReports.Find(id);
            if (report != null)
            {
                report.Status = status;
                _context.SaveChanges();
            }
        }

        public List<ModelRoute> GetApiRoutes() => _context.Routes.ToList();
        public List<Bus> GetApiBuses() => _context.Buses.ToList();
        public List<RouteAssignment> GetApiDriverAssignments(int driverId) =>
            _context.RouteAssignments.Where(ra => ra.DriverId == driverId).ToList();
        public List<BusStop> GetApiRouteStops(int routeId) =>
            _context.BusStops.Where(bs => bs.RouteId == routeId).ToList();
        public List<Student> GetApiRouteStudents(int routeId) =>
            _context.Students.Take(50).ToList();
        public List<BusPass> GetApiStudentPasses(int studentId) =>
            _context.BusPasses.Where(bp => bp.StudentId == studentId).ToList();
        public List<AbsenceReport> GetApiAbsences() => _context.AbsenceReports.ToList();
    }
}