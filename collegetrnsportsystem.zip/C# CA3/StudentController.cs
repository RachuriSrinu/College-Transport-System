using Microsoft.AspNetCore.Mvc;
using CollegeTransportSystem.Models;
using CollegeTransportSystem.Services;
using CollegeTransportSystem.ViewModels;

namespace CollegeTransportSystem
{
    public class StudentController : Controller
    {
        private readonly ITransportService _service;

        public StudentController(ITransportService service)
        {
            _service = service;
        }

        private bool IsStudent() => HttpContext.Session.GetString("UserRole") == "Student";

        private IActionResult CheckStudent()
        {
            if (!IsStudent()) return RedirectToAction("AccessDenied", "Account");
            return null!;
        }

        private int GetCurrentStudentId()
        {
            var userId = HttpContext.Session.GetInt32("UserId") ?? 0;
            var student = _service.GetAllStudents().FirstOrDefault(s => s.UserId == userId);
            return student?.Id ?? 0;
        }

        public IActionResult Dashboard()
        {
            var check = CheckStudent();
            if (check != null) return check;

            var studentId = GetCurrentStudentId();
            var student = _service.GetStudentById(studentId);
            if (student == null) return NotFound();

            var registration = _service.GetRegistrationByStudentId(studentId);
            var busPass = _service.GetBusPassByStudentId(studentId);
            var routes = _service.GetAllRoutes();
            var payments = _service.GetPaymentsByStudentId(studentId);
            var absences = _service.GetAbsenceReportsByStudentId(studentId);

            var model = new StudentDashboardViewModel
            {
                Student = student,
                Registration = registration,
                BusPass = busPass,
                AvailableRoutes = routes,
                PaymentHistory = payments,
                AbsenceReports = absences,
                MonthlyFee = registration != null ? _service.GetRouteById(registration.RouteId)?.MonthlyFee ?? 0 : 0
            };

            return View(model);
        }

        public IActionResult RegisterRoute()
        {
            var check = CheckStudent();
            if (check != null) return check;

            var studentId = GetCurrentStudentId();
            var existing = _service.GetRegistrationByStudentId(studentId);
            if (existing != null && (existing.Status == "Pending" || existing.Status == "Approved"))
            {
                TempData["Info"] = "You already have an active or pending registration.";
                return RedirectToAction("Dashboard");
            }

            var routes = _service.GetAllRoutes();
            return View(routes);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult RegisterRoute(int routeId, int boardingStopId)
        {
            var check = CheckStudent();
            if (check != null) return check;

            var studentId = GetCurrentStudentId();

            var existing = _service.GetRegistrationByStudentId(studentId);
            if (existing != null && (existing.Status == "Pending" || existing.Status == "Approved"))
            {
                TempData["Info"] = "You already have an active or pending registration.";
                return RedirectToAction("Dashboard");
            }

            var registration = new TransportRegistration
            {
                StudentId = studentId,
                RouteId = routeId,
                BoardingStopId = boardingStopId,
                Status = "Pending"
            };

            try
            {
                _service.AddRegistration(registration);
                TempData["Success"] = "Transport application submitted successfully.";
                return RedirectToAction("Dashboard");
            }
            catch (InvalidOperationException ex)
            {
                TempData["Error"] = ex.Message;
                return RedirectToAction("RegisterRoute");
            }
        }

        public IActionResult BusPass()
        {
            var check = CheckStudent();
            if (check != null) return check;

            var studentId = GetCurrentStudentId();
            var busPass = _service.GetBusPassByStudentId(studentId);
            if (busPass == null)
            {
                TempData["Info"] = "No bus pass found.";
                return RedirectToAction("Dashboard");
            }

            var student = _service.GetStudentById(studentId);
            var route = _service.GetRouteById(busPass.RouteId);
            var payment = _service.GetPaymentsByStudentId(studentId).FirstOrDefault();

            var model = new BusPassViewModel
            {
                BusPass = busPass,
                Student = student!,
                Route = route!,
                Payment = payment
            };

            return View(model);
        }

        public IActionResult Payments()
        {
            var check = CheckStudent();
            if (check != null) return check;

            var studentId = GetCurrentStudentId();
            var payments = _service.GetPaymentsByStudentId(studentId);
            return View(payments);
        }

        public IActionResult AbsenceReport()
        {
            var check = CheckStudent();
            if (check != null) return check;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult AbsenceReport(DateTime absenceDate, string reason)
        {
            var check = CheckStudent();
            if (check != null) return check;

            var studentId = GetCurrentStudentId();

            var report = new AbsenceReport
            {
                StudentId = studentId,
                AbsenceDate = absenceDate,
                Reason = reason,
                Status = "Pending"
            };

            _service.AddAbsenceReport(report);
            TempData["Success"] = "Absence report submitted successfully.";
            return RedirectToAction("Dashboard");
        }
    }
}