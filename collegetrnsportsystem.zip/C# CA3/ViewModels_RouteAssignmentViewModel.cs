namespace CollegeTransportSystem.ViewModels
{
    public class RouteAssignmentViewModel
    {
        public int Id { get; set; }
        public int BusId { get; set; }
        public int DriverId { get; set; }
        public int RouteId { get; set; }
        public string? BusNumber { get; set; }
        public string? DriverName { get; set; }
        public string? RouteName { get; set; }
    }
}