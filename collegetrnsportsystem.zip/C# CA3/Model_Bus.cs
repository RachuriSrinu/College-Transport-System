namespace CollegeTransportSystem.Models
{
    public class Bus
    {
        public int Id { get; set; }
        public string BusNumber { get; set; } = string.Empty;
        public string RegistrationNumber { get; set; } = string.Empty;
        public int Capacity { get; set; }
        public string Status { get; set; } = "Active";
    }
}