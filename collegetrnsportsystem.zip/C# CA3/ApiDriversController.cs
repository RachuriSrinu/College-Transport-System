using Microsoft.AspNetCore.Mvc;
using CollegeTransportSystem.Services;

namespace CollegeTransportSystem.Controllers
{
    [ApiController]
    [Route("api/drivers")]
    public class ApiDriversController : ControllerBase
    {
        private readonly ITransportService _service;

        public ApiDriversController(ITransportService service)
        {
            _service = service;
        }

        [HttpGet("{id}/assignments")]
        public IActionResult GetAssignments(int id)
        {
            var assignments = _service.GetApiDriverAssignments(id);
            return Ok(assignments);
        }
    }
}